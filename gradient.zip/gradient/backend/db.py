"""Database layer for Gradient. Uses Python's built-in sqlite3, no ORM needed."""
import os
import sqlite3
from flask import g

DB_PATH = os.environ.get("GRADIENT_DB", os.path.join(os.path.dirname(__file__), "gradient.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT UNIQUE NOT NULL,
    display_name  TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'student',      -- student | advisor
    xp            INTEGER NOT NULL DEFAULT 0,
    state_json    TEXT NOT NULL DEFAULT '{}',           -- full progress blob from the site
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
    token      TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS scores (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    challenge  TEXT NOT NULL,                           -- duel | fact | bias
    score      INTEGER NOT NULL,
    week       TEXT NOT NULL,                           -- e.g. 2026w47
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS duels (
    code         TEXT PRIMARY KEY,
    challenger_id INTEGER NOT NULL REFERENCES users(id),
    challenge    TEXT NOT NULL,
    target_score INTEGER NOT NULL,
    opponent_id  INTEGER REFERENCES users(id),
    opponent_score INTEGER,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS trivia (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    options  TEXT NOT NULL,                             -- JSON list
    answer   INTEGER NOT NULL                           -- index into options
);

CREATE TABLE IF NOT EXISTS trivia_answers (
    user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    trivia_id INTEGER NOT NULL REFERENCES trivia(id),
    day       TEXT NOT NULL,
    correct   INTEGER NOT NULL,
    PRIMARY KEY (user_id, trivia_id, day)
);

CREATE TABLE IF NOT EXISTS mentors (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    initials TEXT NOT NULL,
    title    TEXT NOT NULL,
    kind     TEXT NOT NULL,                             -- Industry | Recent grad | Research
    bio      TEXT NOT NULL,
    tags     TEXT NOT NULL DEFAULT '[]',
    sample   INTEGER NOT NULL DEFAULT 1                 -- 1 = placeholder profile
);

CREATE TABLE IF NOT EXISTS mentor_requests (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mentor_id  INTEGER NOT NULL REFERENCES mentors(id),
    topic      TEXT NOT NULL,
    message    TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'pending',         -- pending | approved | declined
    reviewed_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hackathons (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    name     TEXT NOT NULL,
    region   TEXT NOT NULL,                             -- ga | se | online
    location TEXT NOT NULL,
    timing   TEXT NOT NULL,
    audience TEXT NOT NULL,
    cost     TEXT NOT NULL,
    url      TEXT NOT NULL,
    tags     TEXT NOT NULL DEFAULT '[]',
    approved INTEGER NOT NULL DEFAULT 1,                -- student suggestions start at 0
    submitted_by INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS projects (
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id TEXT NOT NULL,
    reflection TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (user_id, project_id)
);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(SCHEMA)
    db.commit()
    db.close()
