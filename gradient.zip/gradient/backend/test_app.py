"""API tests. Run:  pytest -q"""
import os
import tempfile

import pytest

os.environ["GRADIENT_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ["GRADIENT_ADVISOR_PASSWORD"] = "advisor-pass-123"

import app as gradient  # noqa: E402
import seed  # noqa: E402


@pytest.fixture(scope="module")
def client():
    seed.seed()
    gradient.app.config["TESTING"] = True
    with gradient.app.test_client() as c:
        yield c


def signup(client, name):
    r = client.post("/api/register", json={"username": name, "password": "password123", "display_name": name.title()})
    assert r.status_code == 201, r.json
    return {"Authorization": "Bearer " + r.json["token"]}


def test_health_and_site(client):
    assert client.get("/api/health").json["ok"]
    assert b"Gradient" in client.get("/").data


def test_register_validation(client):
    assert client.post("/api/register", json={"username": "a", "password": "password123"}).status_code == 400
    assert client.post("/api/register", json={"username": "shortpw", "password": "123"}).status_code == 400
    signup(client, "maya")
    assert client.post("/api/register", json={"username": "maya", "password": "password123"}).status_code == 409


def test_login_and_me(client):
    assert client.post("/api/login", json={"username": "maya", "password": "nope"}).status_code == 401
    r = client.post("/api/login", json={"username": "maya", "password": "password123"})
    h = {"Authorization": "Bearer " + r.json["token"]}
    assert client.get("/api/me", headers=h).json["user"]["username"] == "maya"
    assert client.get("/api/me").status_code == 401


def test_progress_xp_cannot_jump_or_drop(client):
    h = signup(client, "leo")
    assert client.put("/api/progress", headers=h, json={"state": {"xp": 120}}).json["xp"] == 120
    assert client.put("/api/progress", headers=h, json={"state": {"xp": 99999}}).json["xp"] == 420   # capped +300
    assert client.put("/api/progress", headers=h, json={"state": {"xp": 5}}).json["xp"] == 420       # can't drop
    board = client.get("/api/leaderboard").json["entries"]
    assert board[0]["display_name"] == "Leo" and board[0]["xp"] == 420


def test_weekly_cup_and_duel(client):
    a, b = signup(client, "ava"), signup(client, "sam")
    cup = client.get("/api/cup").json
    ch = cup["challenge"]
    assert client.post("/api/duels", headers=a, json={"challenge": ch}).status_code == 400  # must play first
    client.post("/api/scores", headers=a, json={"challenge": ch, "score": 70})
    client.post("/api/scores", headers=a, json={"challenge": ch, "score": 999999})          # capped at 400
    entries = client.get("/api/cup").json["entries"]
    assert entries[0] == {"display_name": "Ava", "score": 400}

    code = client.post("/api/duels", headers=a, json={"challenge": ch}).json["code"]
    assert client.get(f"/api/duels/{code}").json["target"] == 400
    assert client.post(f"/api/duels/{code}/result", headers=a, json={"score": 1}).status_code == 400  # own duel
    res = client.post(f"/api/duels/{code}/result", headers=b, json={"score": 50}).json
    assert res["won"] is False and res["target"] == 400
    assert client.post(f"/api/duels/{code}/result", headers=b, json={"score": 50}).status_code == 409


def test_trivia_once_per_day(client):
    h = signup(client, "priya")
    qs = client.get("/api/trivia/today", headers=h).json["questions"]
    assert len(qs) == 3 and "_answer" not in qs[0]
    r = client.post("/api/trivia/answer", headers=h, json={"id": qs[0]["id"], "choice": 0})
    assert "correct" in r.json
    assert client.post("/api/trivia/answer", headers=h, json={"id": qs[0]["id"], "choice": 0}).status_code == 409


def test_mentor_request_needs_advisor(client):
    h = signup(client, "noah")
    mentor_id = client.get("/api/mentors").json["mentors"][0]["id"]
    assert client.post("/api/mentor-requests", headers=h, json={"mentor_id": mentor_id, "message": "hi"}).status_code == 400
    rid = client.post("/api/mentor-requests", headers=h,
                      json={"mentor_id": mentor_id, "topic": "Careers", "message": "What skills should I learn now?"}).json["id"]
    assert client.get("/api/admin/mentor-requests", headers=h).status_code == 403          # students can't approve
    adv = client.post("/api/login", json={"username": "advisor", "password": "advisor-pass-123"}).json["token"]
    ah = {"Authorization": "Bearer " + adv}
    assert any(r["id"] == rid for r in client.get("/api/admin/mentor-requests", headers=ah).json["requests"])
    client.post(f"/api/admin/mentor-requests/{rid}", headers=ah, json={"status": "approved"})
    assert client.get("/api/mentor-requests", headers=h).json["requests"][0]["status"] == "approved"


def test_hackathon_suggestions_hidden_until_approved(client):
    h = signup(client, "zara")
    before = len(client.get("/api/hackathons").json["hackathons"])
    hid = client.post("/api/hackathons", headers=h, json={"name": "Forsyth Hacks", "url": "https://example.org", "region": "ga"}).json["id"]
    assert len(client.get("/api/hackathons").json["hackathons"]) == before
    adv = client.post("/api/login", json={"username": "advisor", "password": "advisor-pass-123"}).json["token"]
    client.post(f"/api/admin/hackathons/{hid}/approve", headers={"Authorization": "Bearer " + adv})
    ga = client.get("/api/hackathons?region=ga").json["hackathons"]
    assert any(x["name"] == "Forsyth Hacks" for x in ga)


def test_projects(client):
    h = signup(client, "jordan")
    assert client.post("/api/projects", headers=h, json={"project_id": "audit", "reflection": "short"}).status_code == 400
    assert client.post("/api/projects", headers=h, json={"project_id": "audit", "reflection": "x" * 50}).status_code == 201
