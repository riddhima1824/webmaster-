"""Fill the database with starting content: trivia, mentors, hackathons, and one advisor account.

Run:  python seed.py
Safe to run more than once; it only seeds empty tables.
"""
import json
import os
import sqlite3

from werkzeug.security import generate_password_hash

from db import DB_PATH, init_db

TRIVIA = [
    ("What does “GPT” stand for?", ["Generative Pre-trained Transformer", "General Purpose Technology", "Graphical Processing Tool", "Guided Prediction Tree"], 0),
    ("The term “artificial intelligence” was coined for a 1956 workshop at which college?", ["Dartmouth", "MIT", "Stanford", "Georgia Tech"], 0),
    ("Which chip type is most commonly used to train large AI models?", ["GPU", "Sound card", "Floppy controller", "Webcam"], 0),
    ("Alan Turing proposed his famous “imitation game” test in…", ["1950", "1965", "1999", "1923"], 0),
    ("AlphaGo defeated Go champion Lee Sedol in…", ["2016", "2006", "2021", "1997"], 0),
    ("IBM’s Deep Blue beat chess champion Garry Kasparov in…", ["1997", "1985", "2008", "2014"], 0),
    ("The “T” in GPT refers to an architecture introduced in 2017. What is it?", ["Transformer", "Tensor", "Turing", "Token"], 0),
    ("A dataset where every example has its correct answer attached is called…", ["Labeled data", "Raw data", "Encrypted data", "Dark data"], 0),
    ("Testing a model on data it has never seen helps detect…", ["Overfitting", "Phishing", "Overclocking", "Compression"], 0),
    ("The small chunks of text an LLM reads are called…", ["Tokens", "Pixels", "Packets", "Cells"], 0),
    ("Which field teaches computers to understand images?", ["Computer vision", "Cryptography", "Networking", "Databases"], 0),
    ("Reinforcement learning trains an agent using…", ["Rewards and penalties", "Only labeled photos", "Spreadsheets", "Random guessing"], 0),
]

# Placeholder profiles. Replace with real volunteers who agree to be listed (set sample = 0).
MENTORS = [
    ("AK", "Machine Learning Engineer", "Industry", "Builds recommendation systems at a retail tech company. Happy to talk about what ML jobs actually look like.", ["ML", "Careers"]),
    ("DR", "AI Product Manager", "Industry", "Decides what AI features get built and how they’re tested for safety. Ask about non-coding AI careers.", ["Product", "Ethics"]),
    ("JL", "Data Scientist, Healthcare", "Industry", "Uses data to predict hospital readmissions. Can talk about bias in medical AI.", ["Data", "Health"]),
    ("MS", "Startup Founder", "Industry", "Runs a small AI startup for local service businesses. Ask about turning a project into a business.", ["Business", "Startups"]),
    ("TB", "CS Freshman, Georgia university", "Recent grad", "Graduated high school last year after doing TSA and hackathons. Ask about college applications and CS classes.", ["College", "Hackathons"]),
    ("NP", "Data Science Sophomore", "Recent grad", "Did a summer AI research program in high school. Ask how to find research opportunities.", ["Research", "College"]),
    ("CW", "AI Ethics Researcher", "Research", "Studies fairness in hiring algorithms. Ask about policy and responsible AI.", ["Ethics", "Policy"]),
    ("EO", "Robotics PhD Student", "Research", "Works on robot perception. Ask about grad school and computer vision.", ["Robotics", "Vision"]),
]

# Dates are from each event's most recent edition (checked Nov 2026).
HACKATHONS = [
    ("HackGwinnett", "ga", "GSMST, Lawrenceville, GA", "Every fall · last held Oct 25, 2025", "Middle & high school students across Georgia", "Free", "https://hackgwinnett.github.io", ["In person", "Beginner friendly"]),
    ("Tech Me Outside", "ga", "Atlanta Tech Park, Peachtree Corners, GA", "One day during Atlanta Tech Week", "Ages 13–18 in Cobb, Gwinnett, North Fulton, Forsyth or Henry counties", "See site", "https://luma.com/tmo2k26", ["AI", "Mentors", "In person"]),
    ("KSU Fintech High School Hackathon", "ga", "KSU Center, Kennesaw, GA", "Every spring · last held Mar 28, 2026", "All Georgia high school students, in teams", "Free · prizes up to $3,000", "https://www.kennesaw.edu/fintech/hackathon/", ["No coding required", "Prizes"]),
    ("Mercer High School Programming Contest", "ga", "Museum of Aviation, Warner Robins, GA", "Every spring · last held Mar 21, 2026", "Grades 9–12, teams of 1–3", "See site", "https://museumofaviation.org/moaevents/high-school-programming-contest/", ["Competitive coding"]),
    ("Daydream (Hack Club game jam)", "ga", "Atlanta, GA (organized by teens at Georgia Tech)", "Last held Sep 27–28, 2025. Watch Hack Club for the next one", "High school & upper middle school, ages 13–18", "Free", "https://daydream.hackclub.com/atlanta", ["Game jam", "In person"]),
    ("Hack BI", "se", "Alexandria, VA", "Every January · last held Jan 17–18, 2026", "High school & middle school, all skill levels", "See site", "https://events.mlh.com", ["MLH member", "300+ hackers"]),
    ("MLH Global Hack Week", "online", "Online", "Week-long themed events throughout the year", "Ages 13+ (under 18 needs parent permission)", "Free", "https://ghw.mlh.com/events", ["Online", "Beginner friendly"]),
]


def seed():
    init_db()
    db = sqlite3.connect(DB_PATH)
    cur = db.cursor()

    if not cur.execute("SELECT 1 FROM trivia LIMIT 1").fetchone():
        cur.executemany("INSERT INTO trivia (question, options, answer) VALUES (?, ?, ?)",
                        [(q, json.dumps(o), a) for q, o, a in TRIVIA])

    if not cur.execute("SELECT 1 FROM mentors LIMIT 1").fetchone():
        cur.executemany("INSERT INTO mentors (initials, title, kind, bio, tags) VALUES (?, ?, ?, ?, ?)",
                        [(i, t, k, b, json.dumps(tags)) for i, t, k, b, tags in MENTORS])

    if not cur.execute("SELECT 1 FROM hackathons LIMIT 1").fetchone():
        cur.executemany(
            "INSERT INTO hackathons (name, region, location, timing, audience, cost, url, tags) VALUES (?,?,?,?,?,?,?,?)",
            [(n, r, l, t, a, c, u, json.dumps(tags)) for n, r, l, t, a, c, u, tags in HACKATHONS])

    # Advisor account approves mentor requests and hackathon suggestions.
    # Change this password before using the site with real students.
    advisor_pw = os.environ.get("GRADIENT_ADVISOR_PASSWORD", "change-me-advisor")
    if not cur.execute("SELECT 1 FROM users WHERE role = 'advisor'").fetchone():
        cur.execute("INSERT INTO users (username, display_name, password_hash, role) VALUES (?, ?, ?, 'advisor')",
                    ("advisor", "TSA Advisor", generate_password_hash(advisor_pw)))

    db.commit()
    db.close()
    print(f"Seeded {DB_PATH}")


if __name__ == "__main__":
    seed()
