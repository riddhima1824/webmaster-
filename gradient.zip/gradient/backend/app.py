"""
Gradient backend: a Flask + SQLite API for the AI learning portal.

Run:
    pip install -r requirements.txt
    python seed.py          # creates gradient.db with starter content
    python app.py           # open http://localhost:5000

The site (index.html, one folder up) is served from "/" so the frontend and API share an origin.
Without this server, the site still works and saves progress in the browser only.
"""
import datetime as dt
import json
import math
import os
import random
import re
import secrets
from functools import wraps

from flask import Flask, g, jsonify, request, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash

from db import close_db, get_db, init_db

SITE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CHALLENGES = ["duel", "fact", "bias"]          # same order as the frontend uses
MAX_CHALLENGE_SCORE = 400                     # 60 seconds can't realistically beat this
MAX_XP_GAIN_PER_SYNC = 300                    # stops someone typing in a fake XP total
USERNAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,20}$")

app = Flask(__name__, static_folder=None)
app.teardown_appcontext(close_db)


# ---------- helpers ----------

def err(message, status=400):
    return jsonify(error=message), status


def body():
    return request.get_json(silent=True) or {}


def today():
    return dt.date.today().isoformat()


def week_key(d=None):
    """Matches weekKey() in index.html so 'this week' means the same thing on both sides."""
    d = d or dt.date.today()
    jan1 = dt.date(d.year, 1, 1)
    js_day = (jan1.weekday() + 1) % 7          # JavaScript getDay(): Sunday = 0
    return f"{d.year}w{math.ceil(((d - jan1).days + js_day + 1) / 7)}"


def featured_challenge(week):
    return CHALLENGES[int(week.split("w")[1]) % len(CHALLENGES)]


def public_user(row):
    return {"id": row["id"], "username": row["username"], "display_name": row["display_name"],
            "role": row["role"], "xp": row["xp"]}


def auth_required(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            header = request.headers.get("Authorization", "")
            token = header[7:] if header.startswith("Bearer ") else None
            if not token:
                return err("Sign in to do that.", 401)
            user = get_db().execute(
                "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?", (token,)
            ).fetchone()
            if not user:
                return err("Your session expired. Sign in again.", 401)
            if role and user["role"] != role:
                return err("Only advisors can do that.", 403)
            g.user = user
            return fn(*args, **kwargs)
        return wrapper
    return deco


def new_session(user_id):
    token = secrets.token_urlsafe(32)
    db = get_db()
    db.execute("INSERT INTO sessions (token, user_id) VALUES (?, ?)", (token, user_id))
    db.commit()
    return token


# ---------- site ----------

@app.get("/")
def index():
    return send_from_directory(SITE_DIR, "index.html")


@app.get("/api/health")
def health():
    return jsonify(ok=True, week=week_key())


# ---------- accounts ----------
# Only a username, display name and password are collected. No email, age or school,
# because the users are high school students.

@app.post("/api/register")
def register():
    data = body()
    username = (data.get("username") or "").strip()
    display = (data.get("display_name") or username).strip()[:24]
    password = data.get("password") or ""
    if not USERNAME_RE.match(username):
        return err("Usernames are 3–20 letters, numbers or underscores.")
    if len(password) < 8:
        return err("Passwords need at least 8 characters.")
    db = get_db()
    if db.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone():
        return err("That username is taken. Try another.", 409)
    cur = db.execute("INSERT INTO users (username, display_name, password_hash) VALUES (?, ?, ?)",
                     (username, display, generate_password_hash(password)))
    db.commit()
    user = db.execute("SELECT * FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(token=new_session(user["id"]), user=public_user(user), state={}), 201


@app.post("/api/login")
def login():
    data = body()
    user = get_db().execute("SELECT * FROM users WHERE username = ?",
                            ((data.get("username") or "").strip(),)).fetchone()
    if not user or not check_password_hash(user["password_hash"], data.get("password") or ""):
        return err("Wrong username or password.", 401)
    return jsonify(token=new_session(user["id"]), user=public_user(user), state=json.loads(user["state_json"]))


@app.post("/api/logout")
@auth_required()
def logout():
    token = request.headers["Authorization"][7:]
    db = get_db()
    db.execute("DELETE FROM sessions WHERE token = ?", (token,))
    db.commit()
    return jsonify(ok=True)


@app.get("/api/me")
@auth_required()
def me():
    return jsonify(user=public_user(g.user), state=json.loads(g.user["state_json"]))


# ---------- progress sync ----------

@app.put("/api/progress")
@auth_required()
def save_progress():
    state = body().get("state")
    if not isinstance(state, dict):
        return err("Send your progress as {\"state\": {...}}.")
    raw = json.dumps(state)
    if len(raw) > 100_000:
        return err("Progress data is too large.", 413)
    old_xp = g.user["xp"]
    new_xp = int(state.get("xp") or 0)
    # XP can only go up, and only by a believable amount per save.
    xp = max(old_xp, min(new_xp, old_xp + MAX_XP_GAIN_PER_SYNC))
    state["xp"] = xp
    db = get_db()
    db.execute("UPDATE users SET xp = ?, state_json = ? WHERE id = ?", (xp, json.dumps(state), g.user["id"]))
    db.commit()
    return jsonify(ok=True, xp=xp)


# ---------- leaderboards & competitions ----------

@app.get("/api/leaderboard")
def leaderboard():
    rows = get_db().execute(
        "SELECT display_name, xp FROM users WHERE role = 'student' ORDER BY xp DESC, id ASC LIMIT 20").fetchall()
    return jsonify(entries=[dict(r) for r in rows])


@app.post("/api/scores")
@auth_required()
def post_score():
    data = body()
    challenge = data.get("challenge")
    if challenge not in CHALLENGES:
        return err("Unknown challenge.")
    score = max(0, min(int(data.get("score") or 0), MAX_CHALLENGE_SCORE))
    db = get_db()
    db.execute("INSERT INTO scores (user_id, challenge, score, week) VALUES (?, ?, ?, ?)",
               (g.user["id"], challenge, score, week_key()))
    db.commit()
    return jsonify(ok=True, score=score), 201


@app.get("/api/cup")
def weekly_cup():
    week = week_key()
    challenge = featured_challenge(week)
    rows = get_db().execute(
        """SELECT u.display_name, MAX(s.score) AS score FROM scores s JOIN users u ON u.id = s.user_id
           WHERE s.week = ? AND s.challenge = ? GROUP BY s.user_id ORDER BY score DESC LIMIT 20""",
        (week, challenge)).fetchall()
    return jsonify(week=week, challenge=challenge, entries=[dict(r) for r in rows])


@app.post("/api/duels")
@auth_required()
def create_duel():
    data = body()
    challenge = data.get("challenge")
    if challenge not in CHALLENGES:
        return err("Unknown challenge.")
    best = get_db().execute("SELECT MAX(score) AS s FROM scores WHERE user_id = ? AND challenge = ?",
                            (g.user["id"], challenge)).fetchone()["s"]
    if best is None:
        return err("Play that challenge once before sending a duel.")
    code = secrets.token_hex(3).upper()                     # e.g. 4F9A2C
    db = get_db()
    db.execute("INSERT INTO duels (code, challenger_id, challenge, target_score) VALUES (?, ?, ?, ?)",
               (code, g.user["id"], challenge, best))
    db.commit()
    return jsonify(code=code, challenge=challenge, target=best), 201


@app.get("/api/duels/<code>")
def get_duel(code):
    row = get_db().execute(
        """SELECT d.*, u.display_name AS challenger FROM duels d JOIN users u ON u.id = d.challenger_id
           WHERE d.code = ?""", (code.upper(),)).fetchone()
    if not row:
        return err("No duel with that code. Check the letters and try again.", 404)
    return jsonify(code=row["code"], challenge=row["challenge"], target=row["target_score"],
                   challenger=row["challenger"], finished=row["opponent_score"] is not None)


@app.post("/api/duels/<code>/result")
@auth_required()
def finish_duel(code):
    db = get_db()
    row = db.execute("SELECT * FROM duels WHERE code = ?", (code.upper(),)).fetchone()
    if not row:
        return err("No duel with that code.", 404)
    if row["challenger_id"] == g.user["id"]:
        return err("You can't accept your own duel. Send the code to a friend.")
    if row["opponent_score"] is not None:
        return err("Someone already played this duel. Ask for a new code.", 409)
    score = max(0, min(int(body().get("score") or 0), MAX_CHALLENGE_SCORE))
    db.execute("UPDATE duels SET opponent_id = ?, opponent_score = ? WHERE code = ?",
               (g.user["id"], score, row["code"]))
    db.execute("INSERT INTO scores (user_id, challenge, score, week) VALUES (?, ?, ?, ?)",
               (g.user["id"], row["challenge"], score, week_key()))
    db.commit()
    return jsonify(won=score > row["target_score"], tie=score == row["target_score"],
                   score=score, target=row["target_score"])


# ---------- daily trivia ----------

def todays_trivia():
    db = get_db()
    rows = db.execute("SELECT * FROM trivia ORDER BY id").fetchall()
    day_num = dt.date.today().toordinal()
    picks = [rows[(day_num * 3 + k) % len(rows)] for k in range(3)]
    out = []
    for r in picks:
        opts = json.loads(r["options"])
        order = list(range(len(opts)))
        random.Random(f"{today()}-{r['id']}").shuffle(order)   # same shuffle all day, hides the answer
        out.append({"id": r["id"], "question": r["question"], "options": [opts[i] for i in order],
                    "_answer": order.index(r["answer"])})
    return out


@app.get("/api/trivia/today")
@auth_required()
def trivia_today():
    answered = {r["trivia_id"]: r["correct"] for r in get_db().execute(
        "SELECT trivia_id, correct FROM trivia_answers WHERE user_id = ? AND day = ?", (g.user["id"], today()))}
    return jsonify(day=today(), questions=[
        {k: v for k, v in q.items() if k != "_answer"} | {"answered": q["id"] in answered}
        for q in todays_trivia()])


@app.post("/api/trivia/answer")
@auth_required()
def trivia_answer():
    data = body()
    q = next((q for q in todays_trivia() if q["id"] == data.get("id")), None)
    if not q:
        return err("That question isn't part of today's trivia.")
    db = get_db()
    if db.execute("SELECT 1 FROM trivia_answers WHERE user_id = ? AND trivia_id = ? AND day = ?",
                  (g.user["id"], q["id"], today())).fetchone():
        return err("You already answered this one today.", 409)
    correct = int(data.get("choice", -1)) == q["_answer"]
    db.execute("INSERT INTO trivia_answers (user_id, trivia_id, day, correct) VALUES (?, ?, ?, ?)",
               (g.user["id"], q["id"], today(), int(correct)))
    db.commit()
    return jsonify(correct=correct, answer=q["_answer"])


# ---------- mentors (every request needs advisor approval) ----------

@app.get("/api/mentors")
def mentors():
    rows = get_db().execute("SELECT * FROM mentors ORDER BY id").fetchall()
    return jsonify(mentors=[dict(r) | {"tags": json.loads(r["tags"]), "sample": bool(r["sample"])} for r in rows])


@app.post("/api/mentor-requests")
@auth_required()
def request_mentor():
    data = body()
    message = (data.get("message") or "").strip()
    topic = (data.get("topic") or "General").strip()[:60]
    if len(message) < 20:
        return err("Add a short message (at least 20 characters).")
    db = get_db()
    if not db.execute("SELECT 1 FROM mentors WHERE id = ?", (data.get("mentor_id"),)).fetchone():
        return err("That mentor doesn't exist.", 404)
    cur = db.execute("INSERT INTO mentor_requests (user_id, mentor_id, topic, message) VALUES (?, ?, ?, ?)",
                     (g.user["id"], data["mentor_id"], topic, message[:500]))
    db.commit()
    return jsonify(id=cur.lastrowid, status="pending"), 201


@app.get("/api/mentor-requests")
@auth_required()
def my_requests():
    rows = get_db().execute(
        """SELECT r.id, r.mentor_id, m.title AS mentor, r.topic, r.message, r.status, r.created_at
           FROM mentor_requests r JOIN mentors m ON m.id = r.mentor_id WHERE r.user_id = ? ORDER BY r.id DESC""",
        (g.user["id"],)).fetchall()
    return jsonify(requests=[dict(r) for r in rows])


# ---------- hackathons ----------

@app.get("/api/hackathons")
def hackathons():
    region = request.args.get("region", "all")
    sql = "SELECT * FROM hackathons WHERE approved = 1"
    args = []
    if region != "all":
        sql += " AND (region = ? OR region = 'online')"
        args.append(region)
    rows = get_db().execute(sql + " ORDER BY region, name", args).fetchall()
    return jsonify(hackathons=[dict(r) | {"tags": json.loads(r["tags"])} for r in rows])


@app.post("/api/hackathons")
@auth_required()
def suggest_hackathon():
    data = body()
    name = (data.get("name") or "").strip()
    url = (data.get("url") or "").strip()
    if not name or not url.startswith(("http://", "https://")):
        return err("Add the event name and a link that starts with https://.")
    db = get_db()
    cur = db.execute(
        """INSERT INTO hackathons (name, region, location, timing, audience, cost, url, tags, approved, submitted_by)
           VALUES (?, ?, ?, ?, 'See site', 'See site', ?, '[]', 0, ?)""",
        (name[:80], data.get("region") if data.get("region") in ("ga", "se", "online") else "se",
         (data.get("location") or "See site")[:80], (data.get("when") or "See site")[:80], url[:200], g.user["id"]))
    db.commit()
    return jsonify(id=cur.lastrowid, status="Waiting for advisor review"), 201


# ---------- projects ----------

@app.post("/api/projects")
@auth_required()
def submit_project():
    data = body()
    reflection = (data.get("reflection") or "").strip()
    if len(reflection) < 40:
        return err("Write a little more (at least 40 characters).")
    db = get_db()
    db.execute("INSERT OR REPLACE INTO projects (user_id, project_id, reflection) VALUES (?, ?, ?)",
               (g.user["id"], str(data.get("project_id"))[:40], reflection[:2000]))
    db.commit()
    return jsonify(ok=True), 201


# ---------- advisor tools ----------

@app.get("/api/admin/mentor-requests")
@auth_required(role="advisor")
def admin_requests():
    status = request.args.get("status", "pending")
    rows = get_db().execute(
        """SELECT r.*, u.display_name AS student, m.title AS mentor FROM mentor_requests r
           JOIN users u ON u.id = r.user_id JOIN mentors m ON m.id = r.mentor_id
           WHERE r.status = ? ORDER BY r.id""", (status,)).fetchall()
    return jsonify(requests=[dict(r) for r in rows])


@app.post("/api/admin/mentor-requests/<int:req_id>")
@auth_required(role="advisor")
def admin_review_request(req_id):
    status = body().get("status")
    if status not in ("approved", "declined"):
        return err("Status must be approved or declined.")
    db = get_db()
    cur = db.execute("UPDATE mentor_requests SET status = ?, reviewed_by = ? WHERE id = ?",
                     (status, g.user["id"], req_id))
    db.commit()
    if not cur.rowcount:
        return err("Request not found.", 404)
    return jsonify(id=req_id, status=status)


@app.get("/api/admin/hackathons")
@auth_required(role="advisor")
def admin_pending_hackathons():
    rows = get_db().execute("SELECT * FROM hackathons WHERE approved = 0 ORDER BY id").fetchall()
    return jsonify(hackathons=[dict(r) for r in rows])


@app.post("/api/admin/hackathons/<int:hack_id>/approve")
@auth_required(role="advisor")
def admin_approve_hackathon(hack_id):
    db = get_db()
    cur = db.execute("UPDATE hackathons SET approved = 1 WHERE id = ?", (hack_id,))
    db.commit()
    if not cur.rowcount:
        return err("Hackathon not found.", 404)
    return jsonify(id=hack_id, approved=True)


if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
