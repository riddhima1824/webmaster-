"""
Gradient — AI Learning Portal: Manim intro animations (3Blue1Brown style)

Install:   pip install manim
Render:    manim -pqh gradient_manim.py NeuralNetIntro
           manim -pqh gradient_manim.py GradientDescent
           manim -pqh gradient_manim.py NextToken
  (-ql = fast low-quality preview, -qh = 1080p final)

Output videos land in ./media/videos/gradient_manim/1080p60/
Embed them in index.html with <video src="..." autoplay muted loop playsinline>.
"""
import random
import numpy as np
from manim import *

BG = "#0a1120"
BLUE_C = "#58c4dd"
YELLOW_C = "#ffd23f"
CORAL = "#ff6b6b"
TEXT = "#e8f0ff"
MUTED = "#9db0d0"

config.background_color = BG


class NeuralNetIntro(Scene):
    """A signal flows through a small network and it predicts 'Cat'."""

    def construct(self):
        random.seed(7)
        title = Text("Inside a neural network", font_size=40, color=TEXT).to_edge(UP)
        self.play(Write(title))

        layers = [3, 5, 5, 2]
        xs = np.linspace(-4.5, 4.5, len(layers))
        nodes = []
        for x, n in zip(xs, layers):
            col = VGroup(*[Circle(radius=0.28, color=BLUE_C, stroke_width=3).set_fill(WHITE, 0.05)
                           for _ in range(n)])
            col.arrange(DOWN, buff=0.35).move_to([x, -0.4, 0])
            nodes.append(col)

        edges = VGroup()
        edge_layers = []
        for l in range(len(layers) - 1):
            group = VGroup()
            for a in nodes[l]:
                for b in nodes[l + 1]:
                    w = random.uniform(-1, 1)
                    line = Line(a.get_right(), b.get_left(),
                                stroke_width=0.6 + abs(w) * 2.4,
                                color=BLUE_C if w > 0 else CORAL)
                    line.set_stroke(opacity=0.25 + abs(w) * 0.5)
                    group.add(line)
            edge_layers.append(group)
            edges.add(group)

        in_labels = VGroup(*[Text(t, font_size=20, color=MUTED).next_to(c, LEFT, buff=0.25)
                             for t, c in zip(["ear shape", "whiskers", "size"], nodes[0])])
        out_labels = VGroup(*[Text(t, font_size=24, color=MUTED).next_to(c, RIGHT, buff=0.25)
                              for t, c in zip(["Cat", "Dog"], nodes[-1])])

        self.play(LaggedStart(*[Create(c) for c in nodes], lag_ratio=0.25), run_time=2)
        self.play(Create(edges), FadeIn(in_labels), FadeIn(out_labels), run_time=2)

        # Activate inputs, then let pulses travel layer by layer
        acts = [[random.uniform(0.2, 1) for _ in range(n)] for n in layers]
        acts[-1] = [0.95, 0.15]
        self.play(*[c.animate.set_fill(WHITE, a) for c, a in zip(nodes[0], acts[0])])
        for l, group in enumerate(edge_layers):
            pulses = [ShowPassingFlash(line.copy().set_stroke(YELLOW_C, width=4), time_width=0.4)
                      for line in group]
            self.play(*pulses, run_time=1.1)
            self.play(*[c.animate.set_fill(WHITE, a) for c, a in zip(nodes[l + 1], acts[l + 1])],
                      run_time=0.5)

        winner = nodes[-1][0]
        self.play(winner.animate.set_stroke(YELLOW_C, width=6),
                  out_labels[0].animate.set_color(YELLOW_C).scale(1.3))
        pred = Text("Prediction: Cat", font_size=34, color=YELLOW_C).to_edge(DOWN)
        self.play(Write(pred))
        self.wait(2)


class GradientDescent(Scene):
    """A ball rolls downhill on the loss curve, tangent line shows the slope."""

    def construct(self):
        f = lambda x: 0.12 * x**4 - 0.9 * x**2 + 0.35 * x + 2.2
        df = lambda x: 0.48 * x**3 - 1.8 * x + 0.35

        axes = Axes(x_range=[-3.4, 3.4, 1], y_range=[-0.5, 7, 1], x_length=11, y_length=5.5,
                    axis_config={"color": "#33476e", "include_ticks": False}).shift(DOWN * 0.4)
        x_lab = Text("weight", font_size=24, color=MUTED).next_to(axes.x_axis, DOWN, buff=0.1).to_edge(RIGHT)
        y_lab = Text("loss", font_size=24, color=MUTED).next_to(axes.y_axis, UP, buff=0.1)
        curve = axes.plot(f, x_range=[-3.3, 3.3], color=BLUE_C, stroke_width=5)
        title = Text("Gradient descent: always step downhill", font_size=36, color=TEXT).to_edge(UP)

        self.play(Write(title))
        self.play(Create(axes), FadeIn(x_lab, y_lab))
        self.play(Create(curve), run_time=2)

        x = ValueTracker(-0.3)
        ball = always_redraw(lambda: Dot(axes.c2p(x.get_value(), f(x.get_value())),
                                         radius=0.14, color=YELLOW_C))
        tangent = always_redraw(lambda: axes.plot(
            lambda t: f(x.get_value()) + df(x.get_value()) * (t - x.get_value()),
            x_range=[x.get_value() - 0.8, x.get_value() + 0.8], color=YELLOW_C, stroke_width=3))
        readout = always_redraw(lambda: Text(
            f"slope = {df(x.get_value()):+.2f}   loss = {f(x.get_value()):.2f}",
            font_size=26, color=MUTED).to_edge(DOWN))
        self.play(FadeIn(ball), Create(tangent), FadeIn(readout))

        lr = 0.12
        for _ in range(14):
            new_x = x.get_value() - lr * df(x.get_value())
            self.play(x.animate.set_value(new_x), run_time=0.35)

        done = Text("Reached the minimum", font_size=30, color=YELLOW_C).next_to(ball, UP, buff=0.4)
        self.play(FadeIn(done, shift=UP * 0.2))
        self.wait(2)


class NextToken(Scene):
    """An LLM picks the next word from a probability distribution."""

    def construct(self):
        sentence = Text("The mitochondria is the powerhouse of the ___", font_size=34, color=TEXT).to_edge(UP)
        self.play(Write(sentence))

        words = ["cell", "body", "plant", "school", "city"]
        probs = [0.72, 0.09, 0.06, 0.04, 0.03]
        chart = BarChart(values=probs, bar_names=words, y_range=[0, 0.8, 0.2],
                         bar_colors=[YELLOW_C, BLUE_C, BLUE_C, BLUE_C, BLUE_C],
                         x_length=9, y_length=4.2).shift(DOWN * 0.6)
        self.play(Create(chart), run_time=2)

        pick = Text("cell", font_size=34, color=YELLOW_C)
        blank = sentence[-3:]
        pick.move_to(blank)
        self.play(Indicate(chart.bars[0], color=YELLOW_C))
        self.play(Transform(blank, pick))
        caption = Text("Predict, pick, repeat. That's how a chatbot writes.", font_size=28,
                       color=MUTED).to_edge(DOWN)
        self.play(FadeIn(caption))
        self.wait(2)
