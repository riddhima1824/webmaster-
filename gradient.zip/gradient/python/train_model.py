"""
Gradient — Level 5 Python starter: train a real AI model.
Same idea as the in-browser Model Lab, but with scikit-learn.

Install:  pip install scikit-learn
Run:      python train_model.py
"""
from sklearn.datasets import make_circles
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures

# 1. Data: two rings of points (like the "Circles" dataset in the Lab)
X, y = make_circles(n_samples=300, noise=0.1, factor=0.5, random_state=0)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# 2. Straight-line model -> underfits
linear = LogisticRegression().fit(X_train, y_train)
print(f"Straight-line features: test accuracy = {linear.score(X_test, y_test):.0%}")

# 3. Add x^2, y^2, xy features -> curved boundary
curved = make_pipeline(PolynomialFeatures(2), LogisticRegression()).fit(X_train, y_train)
print(f"Polynomial features:    test accuracy = {curved.score(X_test, y_test):.0%}")

# 4. Try it on new points
for point in [(0.0, 0.1), (0.9, 0.9)]:
    label = curved.predict([point])[0]
    print(f"Point {point} -> {'inner ring' if label == 1 else 'outer ring'}")
