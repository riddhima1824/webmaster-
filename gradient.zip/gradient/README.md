# Gradient: AI learning portal

An interactive AI learning portal for grades 9–12, built for the TSA Webmaster design brief.

## What's in this folder

| Path | What it is |
|---|---|
| `index.html` | The website (v2 design). HTML, CSS and JavaScript in one file. |
| `gradient-v1.html` | The original dark design, kept as a backup. |
| `backend/app.py` | Flask API: accounts, progress sync, leaderboards, Weekly Cup, duels, trivia, mentor requests, hackathons, advisor tools. |
| `backend/db.py` | SQLite database tables. |
| `backend/seed.py` | Loads starter trivia, mentor profiles, hackathons and the advisor account. |
| `backend/test_app.py` | Automated tests for the API (`pytest`). |
| `python/gradient_manim.py` | 3Blue1Brown-style Manim animations (neural net, gradient descent, next token). |
| `python/train_model.py` | Level 5 starter: train a real classifier with scikit-learn. |

## Run it

**Without the server:** double-click `index.html`. Everything works and progress saves in that browser.

**With the server** (accounts, real leaderboards, advisor approvals):

```bash
cd backend
pip install -r requirements.txt
python seed.py        # creates gradient.db (run once)
python app.py         # then open http://localhost:5000
```

Sign in as the advisor with username `advisor` and password `change-me-advisor`.
Set your own before real students use it:

```bash
GRADIENT_ADVISOR_PASSWORD="something-long" python seed.py
```

Run the tests with `pytest -q` inside `backend/`.

## How the site and server work together

The page checks for `/api/health` when it loads. If the server answers, it turns on:

- **Accounts:** username and password only. No email, age or school is collected because users are high school students. Passwords are hashed with Werkzeug.
- **Progress sync:** XP, badges, streaks and lessons save to your account. The server only lets XP go up by 300 per save, so nobody can type in a fake total.
- **Real leaderboards:** the season leaderboard (total XP) and the Weekly Cup (best score in this week's featured challenge).
- **Friend duels:** a 6-character code. Each code can only be played once, and you can't accept your own.
- **Mentor requests:** every request waits for the advisor to approve or decline it on the Account page.
- **Hackathon suggestions:** students submit events and the advisor approves them before they're listed.

If the server isn't running, the same features fall back to saving in the browser, with sample classmates on the leaderboards.

## API reference

| Method | Endpoint | Who |
|---|---|---|
| GET | `/api/health` | anyone |
| POST | `/api/register`, `/api/login` | anyone |
| POST | `/api/logout` · GET `/api/me` | signed in |
| PUT | `/api/progress` | signed in |
| GET | `/api/leaderboard`, `/api/cup` | anyone |
| POST | `/api/scores` | signed in |
| POST | `/api/duels` · GET `/api/duels/<code>` · POST `/api/duels/<code>/result` | signed in (GET is public) |
| GET | `/api/trivia/today` · POST `/api/trivia/answer` | signed in |
| GET | `/api/mentors` | anyone |
| GET/POST | `/api/mentor-requests` | signed in |
| GET | `/api/hackathons?region=ga` · POST `/api/hackathons` | anyone / signed in |
| POST | `/api/projects` | signed in |
| GET/POST | `/api/admin/mentor-requests[/<id>]`, `/api/admin/hackathons[/<id>/approve]` | advisor only |

## Before submitting

- Replace the sample mentor profiles in `backend/seed.py` (and `MENTORS` in `index.html`) with real volunteers who agreed to be listed.
- Fill in the Our TSA Chapter page.
- Hackathon dates are from each event's last edition. Re-check them before judging.
